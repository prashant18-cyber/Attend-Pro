# Attendance Tracker – Android app

## One-time setup (Windows)
1. Install Node.js (LTS) from nodejs.org
2. Install Android Studio (it also installs the Java it needs)
3. Edit `capacitor.config.json` and change `com.yourname.attendance` to your own ID
   (e.g. com.rahul.attendance). You cannot change it after publishing.

## Create the Android project (run in this folder)
    npm install @capacitor/core @capacitor/android
    npm install -D @capacitor/cli
    npx cap add android
    npx cap sync android
    npx cap open android

## Try it on your phone
Turn on Developer options + USB debugging, plug the phone in,
choose it at the top of Android Studio and press the green Run button.

## Share an APK
Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)

## Publish updates
1. Edit www/index.html
2. npx cap sync android
3. In android/app/build.gradle raise versionCode by 1 (and update versionName)
4. Build > Generate Signed Bundle (AAB) and upload it in Google Play Console

KEEP YOUR .jks KEYSTORE FILE AND PASSWORD BACKED UP. If you lose it you cannot update the app.
